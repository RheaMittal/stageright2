export const MOCK_QUESTIONS = {
  "public-speaking": [
    "Can you elaborate on how this impacts the broader industry?",
    "That's an interesting point, but what about the scalability issues?",
    "Could you clarify the timeline you're proposing?",
    "How does this align with current market trends?",
  ],
  "interview": [
    "Tell me about a time you failed and how you handled it.",
    "Where do you see yourself in 5 years?",
    "How do you prioritize your tasks when under pressure?",
    "Why should we hire you over other candidates?",
  ],
  "live-stream": [
    "Hey! Can you show us that part again?",
    "What gear are you using for this stream?",
    "Someone in chat is asking about the pricing.",
    "Can you give a shoutout to the new subscribers?",
  ],
};

export const MOCK_INSIGHTS = {
  challengingType: "Technical Deep-dives",
  confidenceData: [65, 70, 68, 75, 82, 85, 80, 88, 92, 90],
};

export const CHAT_NAMES = [
  "Rhea", "Kai", "Leo", "Mia", "Zara", "Jay", "Nova", "Finn", "Luna", "Axel"
];

export const CHAT_COMMENTS = [
  "Great point! 👏👏",
  "listening from NYC 🍎",
  "Can you explain that again?",
  "Love the energy today!",
  "Wait, really?",
  "💯💯💯",
  "Interesting perspective...",
  "hi!!!",
  "Sound is clear 👍",
  "Taking notes 📝",
];
