import { createContext, useContext, useState, ReactNode } from "react";

export type PracticeMode = "public-speaking" | "interview" | "live-stream" | null;

export interface SessionConfig {
  mode: PracticeMode;
  duration: number; // minutes
  questionFrequency: "low" | "medium" | "high";
  difficulty: "easy" | "moderate" | "hard";
  context: string;
}

export interface SessionStats {
  durationCompleted: number; // seconds
  questionsAnswered: number;
  performanceScore: number;
  fillerWordCount: number;
  speakingPace: string;
}

interface PracticeContextType {
  config: SessionConfig;
  updateConfig: (updates: Partial<SessionConfig>) => void;
  sessionStats: SessionStats | null;
  setSessionStats: (stats: SessionStats) => void;
  resetSession: () => void;
}

const defaultStats: SessionStats = {
  durationCompleted: 0,
  questionsAnswered: 0,
  performanceScore: 0,
  fillerWordCount: 0,
  speakingPace: "Optimal",
};

const defaultConfig: SessionConfig = {
  mode: null,
  duration: 10,
  questionFrequency: "medium",
  difficulty: "moderate",
  context: "",
};

const PracticeContext = createContext<PracticeContextType | undefined>(undefined);

export function PracticeProvider({ children }: { children: ReactNode }) {
  const [config, setConfig] = useState<SessionConfig>(defaultConfig);
  const [sessionStats, setSessionStats] = useState<SessionStats | null>(null);

  const updateConfig = (updates: Partial<SessionConfig>) => {
    setConfig((prev) => ({ ...prev, ...updates }));
  };

  const resetSession = () => {
    setConfig(defaultConfig);
    setSessionStats(null);
  };

  return (
    <PracticeContext.Provider
      value={{
        config,
        updateConfig,
        sessionStats,
        setSessionStats,
        resetSession,
      }}
    >
      {children}
    </PracticeContext.Provider>
  );
}

export function usePractice() {
  const context = useContext(PracticeContext);
  if (context === undefined) {
    throw new Error("usePractice must be used within a PracticeProvider");
  }
  return context;
}
