import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { usePractice } from "@/lib/context";
import { pageTransition } from "@/components/layout";
import { MOCK_INSIGHTS } from "@/lib/mock-data";
import { CheckCircle, BarChart2, Clock, Zap, Download, RefreshCcw, LayoutGrid, ChevronDown, ChevronUp } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useEffect, useState } from "react";
import confetti from "canvas-confetti";

export default function Feedback() {
  const [, setLocation] = useLocation();
  const { sessionStats, resetSession } = usePractice();
  const [score, setScore] = useState(0);

  useEffect(() => {
    // Animate score and confetti
    if (sessionStats?.performanceScore) {
      const timer = setTimeout(() => {
        setScore(sessionStats.performanceScore);
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FF8E53', '#FF69B4', '#FFD93D']
        });
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [sessionStats]);

  const handleRestart = () => {
    resetSession();
    setLocation("/");
  };

  const insights = [
    { label: "Most Challenging", value: MOCK_INSIGHTS.challengingType, icon: Zap, color: "text-yellow-dark" },
    { label: "Speaking Pace", value: sessionStats?.speakingPace || "Optimal", icon: Clock, color: "text-blue-500" },
    { label: "Filler Words", value: `${sessionStats?.fillerWordCount || 0} detected`, icon: BarChart2, color: "text-pink-brand" },
    { label: "Completion", value: "100%", icon: CheckCircle, color: "text-green-500" },
  ];

  return (
    <motion.div
      variants={pageTransition}
      initial="initial"
      animate="animate"
      exit="exit"
      className="max-w-4xl mx-auto w-full pb-12"
    >
      {/* Summary Card */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-gradient-to-br from-white to-orange-50/50 rounded-3xl p-8 mb-8 shadow-card border border-white relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-secondary opacity-10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2" />
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
          <div>
            <h1 className="text-3xl font-bold text-text-primary mb-2">Session Complete!</h1>
            <p className="text-text-secondary">Great job keeping your composure during the tough questions.</p>
            
            <div className="flex gap-6 mt-6">
              <div>
                <span className="block text-sm text-text-secondary uppercase tracking-wider font-semibold">Duration</span>
                <span className="text-2xl font-bold text-text-primary">
                  {Math.floor((sessionStats?.durationCompleted || 0) / 60)}m {(sessionStats?.durationCompleted || 0) % 60}s
                </span>
              </div>
              <div>
                <span className="block text-sm text-text-secondary uppercase tracking-wider font-semibold">Questions</span>
                <span className="text-2xl font-bold text-text-primary">{sessionStats?.questionsAnswered || 0}</span>
              </div>
            </div>
          </div>

          <div className="relative w-40 h-40 flex items-center justify-center">
             {/* Simple SVG Circle Progress */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="80"
                cy="80"
                r="70"
                stroke="#eee"
                strokeWidth="12"
                fill="transparent"
              />
              <motion.circle
                cx="80"
                cy="80"
                r="70"
                stroke="url(#gradient)"
                strokeWidth="12"
                fill="transparent"
                strokeDasharray={440}
                strokeDashoffset={440 - (440 * score) / 100}
                strokeLinecap="round"
                initial={{ strokeDashoffset: 440 }}
                animate={{ strokeDashoffset: 440 - (440 * score) / 100 }}
                transition={{ duration: 1.5, ease: "easeOut" }}
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#FF6B6B" />
                  <stop offset="100%" stopColor="#FFD93D" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-4xl font-bold text-text-primary">{score}</span>
              <span className="text-sm font-medium text-text-secondary">Score</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Questions Log */}
      <h2 className="text-xl font-bold mb-4 px-2">Question Breakdown</h2>
      <div className="space-y-4 mb-12">
        <Accordion type="single" collapsible className="w-full space-y-4">
          {[1, 2, 3].map((i) => (
            <AccordionItem key={i} value={`item-${i}`} className="border-none">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-xl shadow-sm overflow-hidden"
              >
                <AccordionTrigger className="px-6 py-4 hover:bg-gray-50 hover:no-underline [&[data-state=open]]:bg-gray-50">
                  <div className="flex items-center gap-4 text-left">
                    <div className="w-8 h-8 rounded-full bg-orange-100 text-orange-brand flex items-center justify-center font-bold text-sm">
                      Q{i}
                    </div>
                    <span className="font-medium text-text-primary">
                      {i === 1 ? "Can you elaborate on the scalability issues?" : i === 2 ? "How does this align with market trends?" : "What about the budget implications?"}
                    </span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 pt-2 bg-gray-50">
                  <div className="space-y-4 pl-12 border-l-2 border-orange-200 ml-4">
                    <div>
                      <p className="text-xs font-bold text-text-secondary uppercase mb-1">Your Answer</p>
                      <p className="text-text-primary">"Well, regarding scalability, we plan to implement a microservices architecture..."</p>
                    </div>
                    <div>
                      <p className="text-xs font-bold text-text-secondary uppercase mb-1 flex items-center gap-2">
                        <Zap className="w-3 h-3 text-orange-brand" /> AI Feedback
                      </p>
                      <p className="text-sm text-text-secondary">Good technical depth, but you used "um" twice. Try to pause instead of using filler words.</p>
                    </div>
                  </div>
                </AccordionContent>
              </motion.div>
            </AccordionItem>
          ))}
        </Accordion>
      </div>

      {/* Insights Grid */}
      <h2 className="text-xl font-bold mb-4 px-2">Performance Insights</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
        {insights.map((insight, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 + idx * 0.1 }}
            className="bg-white p-6 rounded-2xl shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow"
          >
            <div className={`p-3 rounded-xl bg-gray-50 ${insight.color}`}>
              <insight.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-text-secondary">{insight.label}</p>
              <p className="text-lg font-bold text-text-primary">{insight.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-center">
        <button
          onClick={handleRestart}
          className="w-full sm:w-auto px-8 py-4 rounded-full bg-gradient-primary text-white font-bold shadow-lg shadow-orange-brand/20 hover:scale-105 transition-transform flex items-center justify-center gap-2"
        >
          <RefreshCcw className="w-5 h-5" />
          Practice Again
        </button>
        <button
          onClick={() => { resetSession(); setLocation("/"); }}
          className="w-full sm:w-auto px-8 py-4 rounded-full border-2 border-gray-200 text-text-primary font-bold hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
        >
          <LayoutGrid className="w-5 h-5" />
          Different Mode
        </button>
      </div>

      {/* Floating Download Button */}
      <motion.button
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1 }}
        className="fixed bottom-8 right-8 bg-white p-4 rounded-full shadow-xl text-text-primary hover:text-orange-brand transition-colors z-40 border border-gray-100"
      >
        <Download className="w-6 h-6" />
      </motion.button>
    </motion.div>
  );
}
