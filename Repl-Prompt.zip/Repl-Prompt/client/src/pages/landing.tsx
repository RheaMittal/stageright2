import { motion } from "framer-motion";
import { Mic, Briefcase, Video } from "lucide-react";
import { useLocation } from "wouter";
import { usePractice, PracticeMode } from "@/lib/context";
import { pageTransition } from "@/components/layout";

export default function Landing() {
  const [, setLocation] = useLocation();
  const { updateConfig } = usePractice();

  const handleSelectMode = (mode: PracticeMode) => {
    updateConfig({ mode });
    setLocation("/config");
  };

  const cards = [
    {
      id: "public-speaking",
      title: "Public Speaking",
      desc: "Master your delivery for keynotes and presentations.",
      icon: Mic,
      delay: 0.1,
    },
    {
      id: "interview",
      title: "Interview Prep",
      desc: "Practice answering tough questions with confidence.",
      icon: Briefcase,
      delay: 0.2,
    },
    {
      id: "live-stream",
      title: "Live Stream",
      desc: "Get comfortable talking to camera and engaging chat.",
      icon: Video,
      delay: 0.3,
    },
  ];

  return (
    <motion.div
      variants={pageTransition}
      initial="initial"
      animate="animate"
      exit="exit"
      className="flex flex-col items-center justify-center min-h-[80vh] w-full max-w-7xl mx-auto"
    >
      <header className="w-full mb-16 text-center lg:text-left relative z-10">
        <div className="flex items-center gap-2 mb-8 justify-center lg:justify-start">
          <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center text-white font-bold">
            S
          </div>
          <span className="font-bold text-xl tracking-tight text-text-primary">StageReady</span>
        </div>
        
        <h1 className="text-5xl md:text-6xl font-bold mb-4">
          Welcome, <span className="text-gradient">Sissi</span>
        </h1>
        <p className="text-text-secondary text-xl">Choose your practice mode</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full">
        {cards.map((card) => (
          <motion.div
            key={card.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: card.delay, duration: 0.5 }}
            className="group relative h-[400px] bg-white rounded-2xl p-8 flex flex-col items-center text-center justify-between shadow-card hover:shadow-hover transition-all duration-300 border border-transparent hover:border-orange-brand/20 cursor-none"
            data-cursor="mic"
            whileHover={{ y: -8 }}
            onClick={() => handleSelectMode(card.id as PracticeMode)}
          >
            {/* Gradient Glow Border Effect */}
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-orange-brand/20 to-pink-brand/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10 blur-xl" />

            <div className="w-20 h-20 rounded-2xl bg-cream-bg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
              <card.icon className="w-10 h-10 text-orange-brand" />
            </div>

            <div className="flex-1 flex flex-col items-center">
              <h3 className="text-2xl font-bold mb-3 text-text-primary">{card.title}</h3>
              <p className="text-text-secondary leading-relaxed">{card.desc}</p>
            </div>

            <button className="w-full py-4 rounded-full bg-gradient-primary text-white font-semibold shadow-lg shadow-orange-brand/20 opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
              Select
            </button>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
