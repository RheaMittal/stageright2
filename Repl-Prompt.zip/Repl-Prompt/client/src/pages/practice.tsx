import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { usePractice } from "@/lib/context";
import { pageTransition } from "@/components/layout";
import { MOCK_QUESTIONS, CHAT_NAMES } from "@/lib/mock-data";
import { VideoFeed } from "@/components/video-feed";
import { ChatStream } from "@/components/chat-stream";
import { ArrowLeft, Clock, MessageSquare, Mic } from "lucide-react";

type InterruptionState = {
  active: boolean;
  name: string;
  question: string;
  state: "idle" | "hand-raised" | "speaking" | "finished";
};

export default function Practice() {
  const [, setLocation] = useLocation();
  const { config, setSessionStats } = usePractice();
  
  const [timeLeft, setTimeLeft] = useState(config.duration * 60);
  const [questionCount, setQuestionCount] = useState(0);
  
  // Interruption State
  const [interruption, setInterruption] = useState<InterruptionState>({
    active: false,
    name: "",
    question: "",
    state: "idle"
  });

  // Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          handleEndSession();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Trigger Interruptions Logic
  useEffect(() => {
    if (interruption.active) return; // Don't trigger if already active

    const questions = MOCK_QUESTIONS[config.mode || "live-stream"];
    
    // Random interruption
    const timer = setTimeout(() => {
      if (questionCount < 4) {
        const randomName = CHAT_NAMES[Math.floor(Math.random() * CHAT_NAMES.length)];
        const randomQuestion = questions[questionCount % questions.length];
        
        setInterruption({
          active: true,
          name: randomName,
          question: randomQuestion,
          state: "hand-raised"
        });
      }
    }, 8000 + Math.random() * 5000);

    return () => clearTimeout(timer);
  }, [questionCount, interruption.active, config.mode]);

  const handleAcceptInterruption = useCallback(() => {
    setInterruption(prev => ({ ...prev, state: "speaking" }));
    
    // Simulate audio playing duration (3 seconds)
    setTimeout(() => {
      setInterruption(prev => ({ ...prev, state: "finished" }));
      setQuestionCount(prev => prev + 1);
    }, 3000);
  }, []);

  const handleFinishSpeaking = useCallback(() => {
    // Reset after question is posted
    // Wait a bit for user to read/answer
    setTimeout(() => {
       // Logic to wait for user to say "Thank you, moving on"?
       // For now, we'll just leave it in 'finished' state (which is effectively 'idle' for the chat UI) 
       // until we reset it fully.
       // Actually, let's reset it to idle so the cycle can restart.
       setInterruption({
         active: false,
         name: "",
         question: "",
         state: "idle"
       });
    }, 5000); // Give 5 seconds to answer before potentially queuing next one? 
              // Or just reset immediately and let the random timer pick it up.
  }, []);

  const handleEndSession = () => {
    setSessionStats({
      durationCompleted: config.duration * 60 - timeLeft,
      questionsAnswered: questionCount,
      performanceScore: 88,
      fillerWordCount: 8,
      speakingPace: "Good",
    });
    setLocation("/feedback");
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <motion.div
      variants={pageTransition}
      initial="initial"
      animate="animate"
      exit="exit"
      className="h-[calc(100vh-2rem)] flex flex-col max-w-7xl mx-auto w-full"
    >
      {/* Top Bar */}
      <header className="flex items-center justify-between mb-4 px-2">
        <div className="flex items-center gap-4">
          <button 
             onClick={() => setLocation("/config")}
             className="p-2 hover:bg-white/50 rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-text-secondary" />
          </button>
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full shadow-sm text-sm font-medium text-text-secondary">
            <Clock className="w-4 h-4" />
            {formatTime(timeLeft)}
          </div>
          <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full shadow-sm text-sm font-medium text-text-secondary">
            <MessageSquare className="w-4 h-4" />
            {questionCount}/4 Questions
          </div>
        </div>

        <div className="flex items-center gap-4">
          {interruption.state === "finished" && (
             <motion.button
               initial={{ scale: 0.9, opacity: 0 }}
               animate={{ scale: 1, opacity: 1 }}
               onClick={() => setInterruption({ active: false, name: "", question: "", state: "idle" })}
               className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg transition-colors flex items-center gap-2"
             >
               <span>Next Question</span>
               <ArrowLeft className="w-4 h-4 rotate-180" />
             </motion.button>
          )}
          <button 
            onClick={handleEndSession}
            className="text-red-500 hover:bg-red-50 px-4 py-2 rounded-lg font-medium text-sm transition-colors"
          >
            End Stream
          </button>
        </div>
      </header>

      {/* Main Split Layout */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0 pb-4">
        
        {/* Left: Video Feed (2/3 width) */}
        <div className="lg:col-span-2 relative">
          <VideoFeed isActive={true} />
        </div>

        {/* Right: Chat Stream (1/3 width) */}
        <div className="lg:col-span-1 h-full min-h-[400px]">
          <ChatStream 
            isActive={timeLeft > 0} 
            interruption={{
              active: interruption.active,
              name: interruption.name,
              question: interruption.question,
              state: interruption.state as any
            }}
            onAcceptInterruption={handleAcceptInterruption}
            onFinishSpeaking={handleFinishSpeaking}
          />
        </div>

      </div>
    </motion.div>
  );
}
