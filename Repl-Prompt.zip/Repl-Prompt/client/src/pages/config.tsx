import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Mic, Briefcase, Video } from "lucide-react";
import { useLocation } from "wouter";
import { usePractice } from "@/lib/context";
import { pageTransition } from "@/components/layout";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function Config() {
  const [, setLocation] = useLocation();
  const { config, updateConfig } = usePractice();
  
  const getIcon = () => {
    switch (config.mode) {
      case "public-speaking": return Mic;
      case "interview": return Briefcase;
      case "live-stream": return Video;
      default: return Mic;
    }
  };

  const Icon = getIcon();

  const handleStart = () => {
    setLocation("/practice");
  };

  return (
    <motion.div
      variants={pageTransition}
      initial="initial"
      animate="animate"
      exit="exit"
      className="max-w-2xl mx-auto w-full pt-8"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-12">
        <button 
          onClick={() => setLocation("/")}
          className="p-2 rounded-full hover:bg-gray-100 transition-colors text-text-secondary"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white shadow-sm border border-gray-100">
          <Icon className="w-4 h-4 text-orange-brand" />
          <span className="font-medium text-sm capitalize">
            {config.mode?.replace("-", " ")} Mode
          </span>
        </div>
        
        <div className="w-10" /> {/* Spacer */}
      </div>

      <div className="bg-white/80 backdrop-blur-md rounded-3xl p-8 md:p-12 shadow-card border border-white space-y-10">
        
        {/* Duration Slider */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Label className="text-lg font-semibold text-text-primary">Session Duration</Label>
            <span className="text-2xl font-bold text-orange-brand">{config.duration} min</span>
          </div>
          <Slider
            defaultValue={[config.duration]}
            max={30}
            min={5}
            step={5}
            onValueChange={(val) => updateConfig({ duration: val[0] })}
            className="py-4"
          />
          <div className="flex justify-between text-xs text-text-secondary px-1">
            <span>5m</span>
            <span>15m</span>
            <span>30m</span>
          </div>
        </div>

        {/* Question Frequency */}
        <div className="space-y-4">
          <Label className="text-lg font-semibold text-text-primary">Question Frequency</Label>
          <div className="grid grid-cols-3 gap-4">
            {(["low", "medium", "high"] as const).map((freq) => (
              <button
                key={freq}
                onClick={() => updateConfig({ questionFrequency: freq })}
                className={`
                  relative py-3 px-4 rounded-full text-sm font-medium transition-all duration-300
                  ${config.questionFrequency === freq 
                    ? "text-white shadow-lg shadow-orange-brand/20 scale-105" 
                    : "bg-gray-50 text-text-secondary hover:bg-gray-100"}
                `}
              >
                {config.questionFrequency === freq && (
                  <motion.div
                    layoutId="freq-bg"
                    className="absolute inset-0 rounded-full bg-gradient-primary -z-10"
                  />
                )}
                <span className="capitalize">{freq}</span>
                <span className="block text-[10px] opacity-80 font-normal">
                  {freq === "low" ? "1-2 Qs" : freq === "medium" ? "3-4 Qs" : "5-6 Qs"}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Difficulty */}
        <div className="space-y-4">
          <Label className="text-lg font-semibold text-text-primary">Difficulty Level</Label>
          <div className="bg-gray-100 p-1 rounded-full flex relative">
            {(["easy", "moderate", "hard"] as const).map((level) => (
              <button
                key={level}
                onClick={() => updateConfig({ difficulty: level })}
                className={`
                  flex-1 py-2 rounded-full text-sm font-medium relative z-10 transition-colors duration-300
                  ${config.difficulty === level ? "text-white" : "text-text-secondary hover:text-text-primary"}
                `}
              >
                <span className="capitalize">{level === "hard" ? "Hard-hitting" : level}</span>
              </button>
            ))}
            <motion.div
              className="absolute top-1 bottom-1 rounded-full bg-gradient-secondary shadow-md z-0"
              initial={false}
              animate={{
                left: config.difficulty === "easy" ? "4px" : config.difficulty === "moderate" ? "33.33%" : "66.66%",
                width: "32%",
                x: config.difficulty === "easy" ? 0 : config.difficulty === "moderate" ? 0 : -4
              }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            />
          </div>
        </div>

        {/* Custom Context */}
        <div className="space-y-4">
          <Label className="text-lg font-semibold text-text-primary">Add Context (Optional)</Label>
          <Textarea
            placeholder="e.g., Tech startup pitch to investors, medical conference presentation about cardiology..."
            className="min-h-[100px] rounded-xl border-gray-200 focus:border-orange-brand/50 bg-gray-50/50 resize-none text-base"
            value={config.context}
            onChange={(e) => updateConfig({ context: e.target.value })}
          />
        </div>

        {/* Dynamic Preview */}
        <div className="bg-orange-50/50 rounded-xl p-4 text-center">
          <p className="text-text-secondary text-sm">
            Your <span className="font-semibold text-orange-brand">{config.duration}-minute</span> session will include 
            <span className="font-semibold text-text-primary">
              {config.questionFrequency === "low" ? " 1-2" : config.questionFrequency === "medium" ? " 3-4" : " 5-6"}
            </span> {config.difficulty} questions about your topic.
          </p>
        </div>

        {/* Start Button */}
        <button
          onClick={handleStart}
          className="w-full py-4 rounded-xl bg-gradient-primary text-white text-lg font-bold shadow-lg shadow-orange-brand/25 hover:shadow-xl hover:shadow-orange-brand/30 hover:scale-[1.02] active:scale-[0.98] transition-all duration-300"
        >
          Start Practice
        </button>
      </div>
    </motion.div>
  );
}
