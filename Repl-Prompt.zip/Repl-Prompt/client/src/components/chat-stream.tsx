import { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CHAT_COMMENTS, CHAT_NAMES } from "@/lib/mock-data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Hand, Mic, Volume2 } from "lucide-react";

interface Comment {
  id: string;
  name: string;
  text: string;
  isQuestion?: boolean;
}

interface ChatStreamProps {
  isActive: boolean;
  interruption: {
    active: boolean;
    name: string;
    question: string;
    state: "hand-raised" | "speaking" | "finished";
  };
  onAcceptInterruption: () => void;
  onFinishSpeaking: () => void;
}

export function ChatStream({ 
  isActive, 
  interruption, 
  onAcceptInterruption,
  onFinishSpeaking 
}: ChatStreamProps) {
  const [comments, setComments] = useState<Comment[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [comments]);

  // Generate random comments
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      // Don't add comments while AI is speaking to keep focus
      if (interruption.state === "speaking") return;

      const randomName = CHAT_NAMES[Math.floor(Math.random() * CHAT_NAMES.length)];
      const randomText = CHAT_COMMENTS[Math.floor(Math.random() * CHAT_COMMENTS.length)];
      
      const newComment: Comment = {
        id: Math.random().toString(36).substr(2, 9),
        name: randomName,
        text: randomText,
      };

      setComments(prev => [...prev.slice(-20), newComment]); // Keep last 20
    }, 2000 + Math.random() * 2000);

    return () => clearInterval(interval);
  }, [isActive, interruption.state]);

  // When AI finishes speaking, add the question to chat
  useEffect(() => {
    if (interruption.state === "finished" && interruption.question) {
      // Check if we already added this specific question to avoid duplicates
      // We can check if the last comment is this question
      const lastComment = comments[comments.length - 1];
      const isDuplicate = lastComment?.isQuestion && lastComment?.text === interruption.question;

      if (!isDuplicate) {
        const questionComment: Comment = {
          id: "question-" + Date.now(),
          name: interruption.name,
          text: interruption.question,
          isQuestion: true
        };
        setComments(prev => [...prev, questionComment]);
        onFinishSpeaking(); // Acknowledge we posted it
      }
    }
  }, [interruption.state, interruption.question, interruption.name, onFinishSpeaking]);

  return (
    <div className="flex flex-col h-full bg-white/80 backdrop-blur-md rounded-3xl shadow-card border border-white overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-white/50">
        <h3 className="font-semibold text-text-primary">Live Chat</h3>
        <div className="flex items-center gap-2 text-xs text-text-secondary">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          {120 + Math.floor(Math.random() * 10)} watching
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 relative overflow-hidden">
        {/* Messages */}
        <div 
          ref={scrollRef}
          className="absolute inset-0 overflow-y-auto p-4 space-y-4 scroll-smooth"
        >
          <AnimatePresence initial={false}>
            {comments.map((comment) => (
              <motion.div
                key={comment.id}
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                className={`flex gap-3 items-start ${comment.isQuestion ? "bg-orange-50 p-3 rounded-xl border border-orange-100" : ""}`}
              >
                <Avatar className="w-8 h-8 border border-white shadow-sm">
                  <AvatarFallback className="bg-gradient-secondary text-white text-xs">
                    {comment.name[0]}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-sm font-bold text-text-primary">{comment.name}</span>
                    {comment.isQuestion && (
                      <span className="text-[10px] bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded-full font-medium">
                        QUESTION
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-text-secondary break-words leading-snug">
                    {comment.text}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Hand Raise / Speaking Overlay */}
        <AnimatePresence>
          {interruption.state === "hand-raised" && (
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="absolute bottom-4 left-4 right-4 z-20"
            >
              <div className="bg-gradient-primary p-[2px] rounded-2xl shadow-xl">
                <div className="bg-white rounded-[14px] p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-orange-100 p-2 rounded-full text-orange-brand">
                      <Hand className="w-5 h-5 animate-bounce" />
                    </div>
                    <div>
                      <p className="font-bold text-text-primary text-sm">{interruption.name} wants to speak</p>
                      <p className="text-xs text-text-secondary">Raised hand just now</p>
                    </div>
                  </div>
                  <button 
                    onClick={onAcceptInterruption}
                    className="bg-text-primary text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-800 transition-colors"
                  >
                    Accept
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {interruption.state === "speaking" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-30 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6"
            >
              <div className="w-20 h-20 rounded-full bg-gradient-secondary p-1 mb-6 relative">
                <Avatar className="w-full h-full border-4 border-white">
                  <AvatarFallback className="bg-gray-100 text-xl font-bold">
                    {interruption.name[0]}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-2 -right-2 bg-white p-2 rounded-full shadow-md text-pink-500">
                  <Mic className="w-4 h-4" />
                </div>
              </div>

              {/* Waveform Animation */}
              <div className="flex items-center gap-1 h-12 mb-4">
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="w-2 bg-gradient-secondary rounded-full"
                    animate={{ 
                      height: ["20%", "100%", "20%"],
                    }}
                    transition={{
                      duration: 0.5,
                      repeat: Infinity,
                      delay: i * 0.1,
                      ease: "easeInOut"
                    }}
                  />
                ))}
              </div>

              <p className="text-lg font-bold text-text-primary mb-2">
                {interruption.name} is asking...
              </p>
              <p className="text-sm text-text-secondary">
                Listening to audio question
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Input Area (Disabled for this demo, usually) */}
      <div className="p-4 border-t border-gray-100 bg-gray-50/50">
        <div className="bg-white border border-gray-200 rounded-full h-10 px-4 flex items-center text-gray-400 text-sm">
          Say something...
        </div>
      </div>
    </div>
  );
}
