import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { Mic } from "lucide-react";

export function CustomCursor() {
  const [isHoveringCard, setIsHoveringCard] = useState(false);
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 25, stiffness: 700 };
  const cursorX = useSpring(mouseX, springConfig);
  const cursorY = useSpring(mouseY, springConfig);

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      mouseX.set(e.clientX - 16); // Center the 32px cursor
      mouseY.set(e.clientY - 16);
    };

    const checkHover = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const card = target.closest('[data-cursor="mic"]');
      setIsHoveringCard(!!card);
    };

    window.addEventListener("mousemove", moveCursor);
    window.addEventListener("mouseover", checkHover);

    return () => {
      window.removeEventListener("mousemove", moveCursor);
      window.removeEventListener("mouseover", checkHover);
    };
  }, [mouseX, mouseY]);

  if (!isHoveringCard) return null;

  return (
    <motion.div
      className="fixed pointer-events-none z-50 flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-orange-brand to-pink-brand shadow-lg text-white"
      style={{
        translateX: cursorX,
        translateY: cursorY,
        left: 0,
        top: 0,
      }}
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0, opacity: 0 }}
    >
      <Mic className="w-6 h-6" />
    </motion.div>
  );
}
