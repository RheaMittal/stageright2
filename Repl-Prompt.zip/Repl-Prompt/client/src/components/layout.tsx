import { ReactNode } from "react";
import { CustomCursor } from "./custom-cursor";
import { motion } from "framer-motion";

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-cream-bg text-text-primary overflow-hidden relative selection:bg-orange-brand/20">
      <CustomCursor />
      
      {/* Background ambient blobs */}
      <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-orange-light/10 blur-[100px] -z-10" />
      <div className="fixed bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-pink-light/10 blur-[100px] -z-10" />
      
      <main className="container mx-auto px-4 py-8 min-h-screen flex flex-col">
        {children}
      </main>
    </div>
  );
}

export const pageTransition = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 },
  transition: { duration: 0.4, ease: "easeOut" }
};
