import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { VideoOff, MicOff, Mic, Video as VideoIcon } from "lucide-react";

export function VideoFeed({ isActive = true }: { isActive?: boolean }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;

    const startVideo = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            width: { ideal: 1280 },
            height: { ideal: 720 },
            facingMode: "user"
          }, 
          audio: false 
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setHasPermission(true);
      } catch (err) {
        console.error("Error accessing webcam:", err);
        setHasPermission(false);
        setError("Camera access denied or unavailable");
      }
    };

    if (isActive) {
      startVideo();
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isActive]);

  return (
    <div className="relative w-full h-full bg-black rounded-3xl overflow-hidden shadow-2xl border border-gray-800 group">
      {hasPermission ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover transform scale-x-[-1]" // Mirror effect
        />
      ) : (
        <div className="flex flex-col items-center justify-center h-full text-gray-400 p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-gray-800 flex items-center justify-center mb-4">
            <VideoOff className="w-8 h-8" />
          </div>
          <p>{error || "Camera inactive"}</p>
        </div>
      )}

      {/* Overlay UI */}
      <div className="absolute top-4 left-4 bg-red-500/90 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-2 animate-pulse">
        <div className="w-2 h-2 bg-white rounded-full" />
        LIVE
      </div>

      <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="bg-black/50 backdrop-blur-md p-2 rounded-full text-white cursor-pointer hover:bg-white/20 transition">
          <Mic className="w-5 h-5" />
        </div>
        <div className="bg-black/50 backdrop-blur-md p-2 rounded-full text-white cursor-pointer hover:bg-white/20 transition">
          <VideoIcon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}
